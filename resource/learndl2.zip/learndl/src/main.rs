use learn_dl::train::{run,infer};
use burn::backend::{wgpu::AutoGraphicsApi, Autodiff, Wgpu};


fn main() {
    type MyBackend = Wgpu<AutoGraphicsApi, f32, i32>;
    type MyAutodiffBackend = Autodiff<MyBackend>;

    let device = burn::backend::wgpu::WgpuDevice::default();
    run::<MyAutodiffBackend>(device.clone());
    infer::<MyBackend>(device);
}
