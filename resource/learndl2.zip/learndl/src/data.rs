use csv::ReaderBuilder;
use std::path::Path;
use serde::{Deserialize,Serialize};
use burn::data::dataset::{Dataset,InMemDataset};
use burn::prelude::*;
use burn::data::dataloader::batcher::Batcher;

#[derive(Debug,Serialize,Deserialize,Clone)]
pub struct WindData{
    #[serde(rename = "wind_production")]
    pub production: f32,
    #[serde(rename = "wind_speed_2m:ms")]
    pub speed2m: f32,
    #[serde(rename = "wind_speed_10m:ms")]
    pub speed10m: f32,
    #[serde(rename = "wind_speed_50m:ms")]
    pub speed50m: f32,
    #[serde(rename = "wind_speed_100m:ms")]
    pub speed100m: f32,
    #[serde(rename = "wind_dir_2m:d")]
    pub dir2m: f32,
    #[serde(rename = "wind_dir_10m:d")]
    pub dir10m: f32,
    #[serde(rename = "wind_dir_50m:d")]
    pub dir50m: f32,
    #[serde(rename = "wind_dir_100m:d")]
    pub dir100m: f32,
}

pub struct WindDataSet{
    dataset: InMemDataset<WindData>,
}

impl WindDataSet{
    pub const TRAIN: &'static str = "./assets/train.csv";
    pub const TEST: &'static str = "./assets/test.csv";

    pub fn load(path: &Path)->Self{
        let mut reader = ReaderBuilder::new();
        let reader = reader.delimiter(b',');
        let dataset = InMemDataset::from_csv(path, reader).unwrap();
        WindDataSet{dataset}
    }

}

impl Dataset<WindData> for WindDataSet{
    fn get(&self, index: usize) -> Option<WindData>{
        self.dataset.get(index)
    }

    fn len(&self) -> usize{
        self.dataset.len()
    }
}

#[derive(Clone,Debug)]
pub struct WindBatch<B: Backend>{
    pub inputs: Tensor::<B,2>,
    pub targets: Tensor::<B,1>,
}

#[derive(Clone,Debug)]
pub struct WindBatcher<B: Backend>{
    device: B::Device,
}

impl<B: Backend> WindBatcher<B>{
    pub fn new(device: B::Device)->Self{
        Self{device}
    }

    pub fn min_max_norm<const D: usize>(&self, inp: Tensor<B,D>)->Tensor<B,D>{
        let min = inp.clone().min_dim(0);
        let max = inp.clone().max_dim(0);
        (inp.clone() - min.clone()).div(max - min)
    }
}

impl<B: Backend> Batcher<WindData, WindBatch<B>> for WindBatcher<B>{
    fn batch(&self, datas: Vec<WindData>) -> WindBatch<B>{
        let mut inputs: Vec<Tensor<B, 2>> = Vec::new();

        for data in datas.iter(){
            let input_tensor = Tensor::<B,1>::from_floats(
                [
                    data.speed2m,
                    data.speed10m,
                    data.speed50m,
                    data.speed100m,
                    data.dir2m,
                    data.dir10m,
                    data.dir50m,
                    data.dir100m,
                ],
                &self.device,
            );

            inputs.push(input_tensor.unsqueeze());
        }

        let inputs = Tensor::cat(inputs,0);
        let inputs = self.min_max_norm(inputs);

        let targets = datas.iter()
            .map(|item|Tensor::<B,1>::from_floats([item.production], &self.device))
            .collect();

        let targets = Tensor::cat(targets,0);
        let targets = self.min_max_norm(targets);

        WindBatch{inputs,targets}

    }
}

