use crate::data::{WindBatcher,WindDataSet};
use crate::model::{RegressionModelConfig,RegressionModel};
use burn::config::Config;
use burn::data::dataloader::batcher::Batcher;
use burn::{
    data::{dataloader::DataLoaderBuilder, dataset::Dataset},
    optim::SgdConfig,
    prelude::*,
    record::{CompactRecorder, NoStdTrainingRecorder,Recorder},
    tensor::backend::AutodiffBackend,
    train::{
        metric::store::{Aggregate, Direction, Split},
        metric::LossMetric,
        LearnerBuilder, MetricEarlyStoppingStrategy, StoppingCondition,
    },
};
use std::path::Path;

static ARTIFACT_DIR: &str = "./wind_fits";

#[derive(Config)]
pub struct ExpConfig {
    #[config(default = 30)]
    pub num_epochs: usize,

    #[config(default = 4)]
    pub num_workers: usize,

    #[config(default = 42)]
    pub seed: u64,

    pub optimizer: SgdConfig,

    #[config(default = 8)]
    pub input_feature_len: usize,

    #[config(default = 720)]
    pub dataset_size: usize,
}

pub fn run<B: AutodiffBackend>(device: B::Device) {
    // Config
    let optimizer = SgdConfig::new();
    let config = ExpConfig::new(optimizer);
    let model = RegressionModelConfig::new(config.input_feature_len).init(&device);
    B::seed(config.seed);

    // Define train/test datasets and dataloaders

    let train_dataset = WindDataSet::load(Path::new(WindDataSet::TRAIN));
    let test_dataset = WindDataSet::load(Path::new(WindDataSet::TEST));

    println!("Train Dataset Size: {}", train_dataset.len());
    println!("Test Dataset Size: {}", test_dataset.len());

    let batcher_train = WindBatcher::<B>::new(device.clone());

    let batcher_test = WindBatcher::<B::InnerBackend>::new(device.clone());

    // Since dataset size is small, we do full batch gradient descent and set batch size equivalent to size of dataset

    let dataloader_train = DataLoaderBuilder::new(batcher_train)
        .batch_size(config.dataset_size)
        .shuffle(config.seed)
        .num_workers(config.num_workers)
        .build(train_dataset);

    let dataloader_test = DataLoaderBuilder::new(batcher_test)
        .batch_size(config.dataset_size)
        .shuffle(config.seed)
        .num_workers(config.num_workers)
        .build(test_dataset);

    // Model
    let learner = LearnerBuilder::new(ARTIFACT_DIR)
        .metric_train_numeric(LossMetric::new())
        .metric_valid_numeric(LossMetric::new())
        .with_file_checkpointer(CompactRecorder::new())
        .early_stopping(MetricEarlyStoppingStrategy::new::<LossMetric<B>>(
            Aggregate::Mean,
            Direction::Lowest,
            Split::Valid,
            StoppingCondition::NoImprovementSince { n_epochs: 1 },
        ))
        .devices(vec![device.clone()])
        .num_epochs(config.num_epochs)
        .summary()
        .build(model, config.optimizer.init(), 5e-3);

    let model_trained = learner.fit(dataloader_train, dataloader_test);

    config
        .save(format!("{ARTIFACT_DIR}/config.json").as_str())
        .unwrap();

    model_trained
        .save_file(
            format!("{ARTIFACT_DIR}/model"),
            &NoStdTrainingRecorder::new(),
        )
        .expect("Failed to save trained model");
}

pub fn infer<B: Backend>(device: B::Device) {
    let config = ExpConfig::load(format!("{ARTIFACT_DIR}/config.json"))
        .expect("Config should exist for the model");

    let record = NoStdTrainingRecorder::new()
        .load(format!("{ARTIFACT_DIR}/model").into(), &device)
        .expect("Trained model should exist");

    let model: RegressionModel<B> = RegressionModelConfig::new(config.input_feature_len).init(&device).load_record(record);

    let test = WindDataSet::load(Path::new(WindDataSet::TEST));
    let mut items = Vec::new();
    for i in 0..720 {
        let item = test.get(i).unwrap();
        items.push(item);
    }

    let batcher = WindBatcher::<B>::new(device.clone());
    let batch = batcher.batch(items);

    let output: Tensor<B, 1> = model.forward(batch.inputs).squeeze(1);
    let target: Tensor<B, 1> = batch.targets;
    let diff = output.clone() - target.clone();
    let diff = diff.mean().into_data();
    println!("Mean Absolute diff: {}", diff);

    
}